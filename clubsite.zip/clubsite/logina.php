<!DOCTYPE html>
<html>
	<head>
		<title> Login </title>
	</head>
	<body>
    Login:
		<form action="loginb.php" method="post">

			Email: <input type="text" name="Email">

			<br>

			Password: <input type="text" name="Password">
            
            <br>

			<input type="submit">

		</form>
        <br>
Signup:


	    <form action="accreation.php" method="post">

	    	<input type="submit" value="Create Account"/>
	    </form>
	</body>
</html>