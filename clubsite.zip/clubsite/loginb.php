<?
        session_start();

    $hostname = "185.27.134.10";

    $username = "epiz_33159059";

    $dbname = "epiz_33159059_Tedstnhill"; 

    $password = "vzOT3d2L8OWb";

    @mysql_connect($hostname, $username, $password) OR DIE ("Unable to connect to database! Please try again later.");

    @mysql_select_db($dbname);    



    $email=$_POST['Email'];

    $passwords=$_POST['Password'];
    $passwords=md5($passwords);


    $query="SELECT * FROM Users WHERE Username='$email' AND Password='$passwords'";
    
    @$result=mysql_query($query);

    @$rows=mysql_num_rows($result);

    if($rows>0)

    {
        $USER=mysql_fetch_array($result);
        $id=$USER["USERID"];

        $_SESSION['userid']=$id;

        header("Location: http://legallydistincttalks.great-site.net/dashboard.php");
       
       
    }
    else
    { 
    	exit("The login username and password do not seem to match.");
    }

?>