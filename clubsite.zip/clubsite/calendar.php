<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Calendar</title>
</head>
<body>
<?
$check=$_POST["check"];
if($check==1)
?>
<table border="1" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td>
<table style="height: 407px; width: 893px;" border="1" width="477" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width: 128.422px;" align="center" bgcolor="#1797ad"><span style="font-family: Tahoma; font-size: medium;"> <a href="html_calendar.php?prm=10&amp;chm=-1" rel="nofollow">&lt;</a></span></td>
<td style="width: 641.906px;" colspan="5" align="center" bgcolor="#1797ad"><span style="font-family: Tahoma; font-size: medium;">Oct 2021 </span></td>
<td style="width: 118.25px;" align="center" bgcolor="#1797ad"><span style="font-family: Tahoma; font-size: medium;"> <a href="html_calendar.php?prm=10&amp;chm=1" rel="nofollow">&gt;</a> </span></td>
</tr>
<tr>
<td style="width: 128.484px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Sun</strong></span></td>
<td style="width: 137.438px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Mon</strong></span></td>
<td style="width: 125.359px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Tue</strong></span></td>
<td style="width: 140.328px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Wed</strong></span></td>
<td style="width: 127.281px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Thu</strong></span></td>
<td style="width: 107.297px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Fri</strong></span></td>
<td style="width: 118.359px;"><span style="font-family: Tahoma; font-size: medium;"><strong>Sat</strong></span></td>
</tr>
<tr>
<td style="width: 128.5px;">&nbsp;</td>
<td style="width: 137.516px;">&nbsp;</td>
<td style="width: 125.391px;">&nbsp;</td>
<td style="width: 140.359px;">&nbsp;</td>
<td style="width: 127.297px;">&nbsp;</td>
<td style="width: 107.375px;" valign="top"><span style="font-family: Tahoma; font-size: small;">1 <br /></span></td>
<td style="width: 118.422px;" valign="top"><span style="font-family: Tahoma; font-size: small;">2 <br /></span></td>
</tr>
<tr>
<td style="width: 128.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">3 <br /></span></td>
<td style="width: 137.531px;" valign="top"><span style="font-family: Tahoma; font-size: small;">4 <br /></span></td>
<td style="width: 125.391px;" valign="top"><span style="font-family: Tahoma; font-size: small;">5 <br /></span></td>
<td style="width: 140.359px;" valign="top"><span style="font-family: Tahoma; font-size: small;">6 <br /></span></td>
<td style="width: 127.312px;" valign="top"><span style="font-family: Tahoma; font-size: small;">7 <br /></span></td>
<td style="width: 107.406px;" valign="top"><span style="font-family: Tahoma; font-size: small;">8 <br /></span></td>
<td style="width: 118.469px;" valign="top"><span style="font-family: Tahoma; font-size: small;">9 <br /></span></td>
</tr>
<tr>
<td style="width: 128.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">10 <br /></span></td>
<td style="width: 137.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">11 <br /></span></td>
<td style="width: 125.391px;" valign="top"><span style="font-family: Tahoma; font-size: small;">12 <br /></span></td>
<td style="width: 140.344px;" valign="top"><span style="font-family: Tahoma; font-size: small;">13 <br /></span></td>
<td style="width: 127.297px;" valign="top"><span style="font-family: Tahoma; font-size: small;">14 <br /></span></td>
<td style="width: 107.406px;" valign="top"><span style="font-family: Tahoma; font-size: small;">15 <br /></span></td>
<td style="width: 118.531px;" valign="top"><span style="font-family: Tahoma; font-size: small;">16 <br /></span></td>
</tr>
<tr>
<td style="width: 128.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">17 <br /></span></td>
<td style="width: 137.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">18 <br /></span></td>
<td style="width: 125.391px;" valign="top"><span style="font-family: Tahoma; font-size: small;">19 <br /></span></td>
<td style="width: 140.344px;" valign="top"><span style="font-family: Tahoma; font-size: small;">20 <br /></span></td>
<td style="width: 127.297px;" valign="top"><span style="font-family: Tahoma; font-size: small;">21 <br /></span></td>
<td style="width: 107.406px;" valign="top"><span style="font-family: Tahoma; font-size: small;">22 <br /></span></td>
<td style="width: 118.531px;" valign="top"><span style="font-family: Tahoma; font-size: small;">23 <br /></span></td>
</tr>
<tr>
<td style="width: 128.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">24 <br /></span></td>
<td style="width: 137.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">25 <br /></span></td>
<td style="width: 125.391px;" valign="top"><span style="font-family: Tahoma; font-size: small;">26 <br /></span></td>
<td style="width: 140.344px;" valign="top"><span style="font-family: Tahoma; font-size: small;">27 <br /></span></td>
<td style="width: 127.297px;" valign="top"><span style="font-family: Tahoma; font-size: small;">28 <br /></span></td>
<td style="width: 107.406px;" valign="top"><span style="font-family: Tahoma; font-size: small;">29 <br /></span></td>
<td style="width: 118.531px;" valign="top"><span style="font-family: Tahoma; font-size: small;">30 <br /></span></td>
</tr>
<tr>
<td style="width: 128.516px;" valign="top"><span style="font-family: Tahoma; font-size: small;">31 <br /></span></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<p><br /><br /><br /><br /></p>
<form action="Deadline.php" method="post">Add a new deadline:<input name="" type="submit" /></form>
<?
else
print("incorrect login")
?>
</body>
</html>