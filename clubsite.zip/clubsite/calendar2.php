<?
	session_start();
	if (!isset($_SESSION['userid'])) {
	  //The user has not logged in
		header("Location: http://legallydistincttalks.great-site.net/logina.php?");
	} 
	include("calendarfunction.php");
	
	$USERID=$_SESSION["userid"];
	$dateComponents = getdate();

        $my=$_POST['MY'];
        $mon=$_GET["mon"];
        $yr=$_GET["yr"];

    $year=0;
    $month=0;
    if(isset($my))
    {
        $a = explode('-', $my);
        $year=$a[0];
        $month=$a[1];
    }
    else
    {
       $month = $dateComponents['mon']; 			     
       $year = $dateComponents['year'];
    } 
     if($mon>0)
    {
        $month=$mon;
        $year=$yr;
    }
	$query="SELECT *
FROM Archive
WHERE Archive.Date>='$year-$month-01' AND Archive.Date<='$year-$month-31'";

//***************************************************************
	
	$hostname = "45.40.164.18";
    $username = "CSstonehill";
    $dbname = "CSstonehill"; 
    $password = "D1student!";
    @mysql_connect($hostname, $username, $password) OR DIE ("Unable to connect to database! Please try again later.");
    @mysql_select_db($dbname);    
//***************************************************************


    @$result=mysql_query($query);
    $c=0;
    while($row=mysql_fetch_array($result))
    {
    	$TASKS[$c]=$row;
    	$c++;
    }
	print("User logged in is ID:");
	print($USERID);



    

?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?
	     print (build_calendar($month,$year,$TASKS));
?>
<form action="calendar2.php" method="post">

            Month and Year: <input type="month" name="MY">

            <br>

            <input type="submit">
            </form>
</body>
</html>