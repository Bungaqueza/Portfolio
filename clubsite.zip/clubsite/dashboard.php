<!DOCTYPE html>
<html>
	<head>
		<title> Login </title>
	</head>
	<body>
		<?
		session_start();
	if (!isset($_SESSION['userid'])) {
		header("Location: http://legallydistincttalks.great-site.net/logina.php?");
	} 
	?>
	    <form action="aboutus.php" method="post">

	    	<input type="submit" value="About us"/>

	    </form>
	    <form action="archive.php" method="post">

	    	<input type="submit" value="Archive"/>

	    </form>
	    <form action="stats.php" method="post">

	    	<input type="submit" value="Stats"/>
	    <form action="speakapp.php" method="post">

	    	<input type="submit" value="Speaker Application"/>

	    </form>
        <form action="calendar.php" method="post">

	    	<input type="submit" value="Calendar"/>

	    </form>
	    <form action="chat.php" method="post">

	    	<input type="submit" value="Chat"/>

	    </form>
	</body>
</html>