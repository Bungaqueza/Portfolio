using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Burst.CompilerServices;
using Unity.Mathematics;
using UnityEngine;


public class lookat : MonoBehaviour
{
    GameManager gameManager;

    public Transform player;
    public GameObject enemyproj;
    private bool alreadyattacked = false;
    public float health = 50f;
    public Vector3 shootpos = Vector3.up;
    public float distance;
    public GameObject gate;
    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
        player = GameObject.FindWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        distance=Vector3.Distance(player.position,transform.position);
        if (distance<20)
        {
            this.transform.LookAt(player);
            Shoot();
        }
        
    }
    private void Shoot()
    {
        if (!alreadyattacked)
        {
            Rigidbody rb = Instantiate(enemyproj,transform.position,Quaternion.identity).GetComponent<Rigidbody>();
            rb.AddForce(transform.forward*32f,ForceMode.Impulse);
            rb.AddForce(transform.up*3f,ForceMode.Impulse);
            alreadyattacked = true;
            Invoke(nameof(ResetAttack), 2);
        }
    }
    private void ResetAttack()
    {
        alreadyattacked = false;
    }
    public void takeDamage(float amount)
    {
        health -= amount;
        if (health <= 0)
        {

            Die();
        }
    }
    void Die()
    {
        Destroy(gameObject,0.2f);
        if (gate != null)
        {
            Destroy(gate);
        }
        gameManager.killCount++;
    }
}
