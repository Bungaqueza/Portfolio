using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class shoot : MonoBehaviour
{
    Animator animator;

    [Header("Atributes")]
    [SerializeField] string shootType;
    GameManager gameManager;

    [Header("Shoot Handling")]
    [SerializeField] Camera maincam;
    [SerializeField] int range;
    [SerializeField] float damage;
    [SerializeField] bool alreadyattacked = false;

    [Header("Shoot Effects")]
    [SerializeField] ParticleSystem muzzleflash;
    [SerializeField] AudioClip[] shootSoundEffects;

    Player player;

    [SerializeField] float shootdrain;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();

        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
        maincam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && player.shootBar>=shootdrain)
        {
            Invoke(nameof(Fire), 0f);
            
        }
        if (player.shootBar < shootdrain)
        {
            Invoke(nameof(RegenShoot), 2f);
        }

    }
    private void Fire()
    {
        if(gameManager.isInUI == false) {
        gameManager.CheckSequence(shootType);
            if (!alreadyattacked)
            {
                player.shootBar = player.shootBar - shootdrain;
                animator.SetTrigger("shoot");

                if (shootSoundEffects != null && shootSoundEffects.Length > 0)
                {
                    SoundEffectManager.instance.PlayRandomSoundEffectClip(shootSoundEffects, transform, 1f);
                }

                muzzleflash.Play();

                RaycastHit hit;
                if (Physics.Raycast(maincam.transform.position, maincam.transform.forward, out hit, range))
                {
                    Transform objectHit = hit.transform;
                    Debug.Log(hit.transform.name);
                    enemy target = hit.transform.GetComponent<enemy>();
                    lookat target2 = hit.transform.GetComponent<lookat>();
                    enemytut target3 = hit.transform.GetComponent<enemytut>();
                    if (objectHit != null && objectHit.GetComponent<enemy>() != null)
                    {
                        target.takeDamage(damage);
                    }
                    if (objectHit != null && objectHit.GetComponent<lookat>() != null)
                    {
                        target2.takeDamage(damage);
                    }
                    if (objectHit != null && objectHit.GetComponent<enemytut>() != null)
                    {
                        target3.takeDamage(damage);
                    }
                    if (objectHit != null && objectHit.GetComponent<SimonSkull>() != null)
                    {
                        SimonSkull sSkull = objectHit.GetComponent<SimonSkull>();
                        sSkull.GetShot();
                    }
                    //Instantiate(impact, hit.point+(hit.normal*0.1f), Quaternion.FromToRotation(Vector3.up,hit.normal));;
                }
                alreadyattacked = true;
                Invoke(nameof(ResetAttack), 0.5f);
            }
        }




    }
    private void ResetAttack()
    {
        alreadyattacked = false;
    }
    private void RegenShoot()
    {
        if (player.shootBar <= 100)
        {
            player.shootBar = player.shootBar + 40 * Time.deltaTime;
        }
    }
}