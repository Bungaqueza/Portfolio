using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    [SerializeField] float speed;
    public Rigidbody rb;
    private float _vInput;
    private float _hInput;
    public GameObject cam;
    public Transform transCam = null;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

    }
    private void FixedUpdate()
    {
        _vInput = Input.GetAxis("Vertical") * speed;
        _hInput = Input.GetAxis("Horizontal") * speed;
        /*var camera = Camera.main;
        var forward = camera.transform.forward;
        var right = camera.transform.right;
        forward.y=0f;
        right.y=0f;
        forward.Normalize();
        right.Normalize();
        var dir = forward*_vInput+right*_hInput;
        transform.Translate(dir*speed*Time.deltaTime);*/
        this.transform.Translate(transform.forward * _vInput * Time.deltaTime);
        this.transform.Translate(transform.right * _hInput * Time.deltaTime);
        this.transform.rotation = cam.transform.rotation;
        //this.transform.rotation = Quaternion.Euler(this.transform.rotation.x,transCam.rotation.y,this.transform.rotation.z);
    }
}
