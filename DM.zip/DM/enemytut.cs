using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemytut : MonoBehaviour
{
    public float health = 25f;
    public ParticleSystem defect;
    public Material Mat;
    public GameObject skul;
    public bool hit;
    public GameObject player;
    public GameObject tutbox;

    public void takeDamage(float amount)
    {
        health -= amount;
        if (health <= 0)
        {

            Die();
        }
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    void Die()
    {
        //Destroy(gameObject,3f);
        defect.Play();
        skul.GetComponent<MeshRenderer>().material = Mat;
        if (hit != true)
        {
            Destroy(tutbox);
        }
    }
}
