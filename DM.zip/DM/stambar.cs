using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stambar : MonoBehaviour
{
    Renderer rend;
    //public GameObject player;
    private Player playerstam;
    float stamina;


    // Start is called before the first frame update
    void Start()
    {
        playerstam = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();

        rend = GetComponent<Renderer>();
        //playerstam=player.GetComponent<Player>();
    }

    // Update is called once per frame
    void Update()
    {
        rend.material.SetFloat("_fill", (playerstam.stamina/100));
    }
}
