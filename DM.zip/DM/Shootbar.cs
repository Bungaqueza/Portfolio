using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shootbar : MonoBehaviour
{
    Renderer rend;
    public GameObject gun;
    //private shoot playershoot;

    float stamina;
    Player player;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();

        rend = GetComponent<Renderer>();
        //playershoot = gun.GetComponent<shoot>();
    }

    // Update is called once per frame
    void Update()
    {
       rend.material.SetFloat("_fill", (player.shootBar / 100));
    }
}
