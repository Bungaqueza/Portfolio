using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyproj : MonoBehaviour
{
    public float damage=20;
    // Start is called before the first frame update
    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log(collision.transform.name);
        if (collision.transform.tag == "Player")
        {
            Debug.Log("hitplayer");
            // do damage here, for example:
            collision.gameObject.GetComponent<healtheffect>().takeDamage(damage);
            Destroy(this.gameObject);
        }
        Destroy(this.gameObject,0.5f);
        
    }
    private void Update()
    {
        //Destroy(gameObject, 2f);
    }
    
}

